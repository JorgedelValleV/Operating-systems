gcc -Wall -g leds_user.c -o leds_user
sudo ./leds_user